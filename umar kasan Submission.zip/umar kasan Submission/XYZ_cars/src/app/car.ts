export interface Car {
    id: number;
    make: string;
    model: string;
    year: string;
    description: string;
    image_url: string;
}